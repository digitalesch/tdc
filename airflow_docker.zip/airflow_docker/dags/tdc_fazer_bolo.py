"""Examplo de dag que foi mostrado como pseudo-código"""

from datetime import timedelta
from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.utils.dates import days_ago

args = {
    'owner': 'airflow',
}

tarefas = {
    1:'ingredientes_utensilios',
    2:'preparar_massa',
    3:'untar_forma',
    4:'utilizar_forno',
    5:'comer_bolo'
}

with DAG(
    dag_id='tdc_checklist_fazer_bolo',
    default_args=args,
    schedule_interval='@once',
    start_date=days_ago(1),
    tags=['tdc', 'checklist','bolo']
) as dag:

    # cria as tarefas sem dependecias ou correlação
    for chave,valor in tarefas.items():
        
        globals()['tarefa_'+str(chave)] = DummyOperator(
            task_id=valor,
        )

    globals()['tarefa_1'] >> globals()['tarefa_2']
    globals()['tarefa_1'] >> globals()['tarefa_3']
    globals()['tarefa_2'] >> globals()['tarefa_4']
    globals()['tarefa_3'] >> globals()['tarefa_4']
    globals()['tarefa_4'] >> globals()['tarefa_5']
    
    # Erro para demonstrar que não pode haver ciclos
    #globals()['tarefa_5'] >> globals()['tarefa_1']