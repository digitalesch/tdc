from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.utils.dates import days_ago

args = {
    'owner': 'airflow',
    'depends_on_past': False,
}

with DAG(
    dag_id='tdc_hello_world',
    schedule_interval='@daily',
    start_date=days_ago(1),
    default_args=args,
    tags=['tdc'],
) as dag:

    hello_world = BashOperator(
        task_id='HELLO_TDC',
        bash_command='echo HELLO TDC, ESTOU FAZENDO MEU PRIMEIRO DAG!',
    )