from airflow import DAG
from airflow.models import Variable

# Operadores
from airflow.operators.python import PythonOperator
from airflow.operators.postgres_operator import PostgresOperator
from airflow.hooks.postgres_hook import PostgresHook

# Configuracao do airfloow
from airflow.utils.dates import days_ago

import os
import yaml

def teste_read_variable(**context):
    print(context['params'])

    sql_query = ('select * from '+ context['params']['source']['table']) if 'sql' not in context['params'] else context['params']['sql']

    # lê o source
    source_data = PostgresHook(context['params']['source']['name']).get_pandas_df(sql_query)
    # apenas renomeia as colunas para minusculo caso exista
    source_data.columns = map(str.lower, source_data.columns)
    
    # hook para o destino
    destination_hook = PostgresHook(context['params']['destination']['name'])

    # escreve o dataframe no destino
    source_data.to_sql(name=context['params']['destination']['table'],con=destination_hook.get_sqlalchemy_engine(),if_exists='append',index=False,chunksize=10000,method="multi")
    
default_args = {
    'owner': 'airflow',
    'description':'DAG-Factory PostgreSQL - PostgreSQL',
    'schedule_interval':'@daily',
    'start_date':days_ago(1),
}

# procura no diretorio os yamls
files = os.listdir(Variable.get('yaml_path'))
    
dag_factory_config = []

# cria dicionario para cada arquivo encontrado
for file in files:
    with open('yaml_config/'+file) as f:
        dag_factory_config.append({'file':file.split('.')[0],'config':yaml.safe_load(f)})

# cria DAGs dinamicamente
for dag_yaml_config in dag_factory_config:
    globals()[dag_yaml_config['file']]=DAG(dag_id='pg_to_pg_'+dag_yaml_config['file'],default_args=default_args,tags=['tdc','dag_factory','pg_to_pg',dag_yaml_config['file']])

    py_task = PythonOperator(
        task_id='pg_to_pg_transfer',
        # funcao de leitura
        python_callable=teste_read_variable,
        provide_context = True,
        params=dag_yaml_config['config'],
        dag=globals()[dag_yaml_config['file']]
    )