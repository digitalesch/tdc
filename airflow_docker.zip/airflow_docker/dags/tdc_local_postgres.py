from airflow import DAG
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators.branch import BaseBranchOperator
from airflow.utils.dates import days_ago

args = {
    'owner': 'airflow',
    'depends_on_past': False,
}

with DAG(
    dag_id="tdc_local_postgres",
    start_date=days_ago(1),
    schedule_interval="@once",
    default_args=args,
    catchup=False,
    tags=['tdc'],
) as dag:
    create_pet_table = PostgresOperator(
        task_id="create_pet_table",
        postgres_conn_id="tdc_local_postgres",
        sql="""
            CREATE TABLE IF NOT EXISTS pet (
            pet_id SERIAL PRIMARY KEY,
            name VARCHAR NOT NULL,
            pet_type VARCHAR NOT NULL,
            OWNER VARCHAR NOT NULL);
          """,
    )